import React from 'react'

const PageTwo = React.createClass({
	render() {
		return <h2>Page Two! Wooo!</h2>
	}
})

export default PageTwo
